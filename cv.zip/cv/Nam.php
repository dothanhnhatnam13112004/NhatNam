<?php
// Thông tin cá nhân
$ten = "Đỗ Thanh Nhật Nam";
$viTri = "Thực tập sinh UI/UX Designer";
$ngaySinh = "13/11/2004";
$tuoi = 21;
$email = "dbannam8@gmail.com";
$soDienThoai = "0367299654";
$diaChi = "1/105 Xuân 68";
$gioiThieu = "Sinh viên Công nghệ Thông tin với niềm đam mê về thiết kế trải nghiệm người dùng (UX) và giao diện người dùng (UI).
Mong muốn được học hỏi, thực tập và phát triển kỹ năng trong môi trường chuyên nghiệp.";

// Ảnh đặt cùng thư mục với cv.php
$anhDaiDien = "anh3x4.PNG";
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CV <?= $ten ?></title>
    <style>
        body {font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; color: #333;}
        .cv-container {max-width: 900px; margin: 30px auto; background: #fff; border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden;}
        header {background: #2d89ef; color: white; padding: 30px; text-align: center; position: relative;}
        header h1 {margin: 10px 0 0; font-size: 28px;}
        header p {margin: 5px 0;}
        .avatar {
            width: 120px; height: 120px;
            border-radius: 50%;
            border: 4px solid #fff;
            object-fit: cover;
            position: absolute;
            top: 20px; left: 20px;
        }
        section {padding: 20px 30px; border-bottom: 1px solid #eee;}
        section h2 {font-size: 20px; margin-bottom: 10px; color: #2d89ef;}
        ul {margin: 0; padding-left: 20px;}
        .contact-info p {margin: 4px 0;}
    </style>
</head>
<body>
<div class="cv-container">
    <header>
        <img src="<?= $anhDaiDien ?>" alt="Ảnh đại diện" class="avatar">
        <h1><?= $ten ?></h1>
        <p><?= $viTri ?></p>
    </header>

    <section class="contact-info">
        <h2>Thông tin cá nhân</h2>
        <p><strong>Ngày sinh:</strong> <?= $ngaySinh ?> (<?= $tuoi ?> tuổi)</p>
        <p><strong>Email:</strong> <?= $email ?></p>
        <p><strong>Số điện thoại:</strong> <?= $soDienThoai ?></p>
        <p><strong>Địa chỉ:</strong> <?= $diaChi ?></p>
    </section>

    <section>
        <h2>Giới thiệu</h2>
        <p><?= $gioiThieu ?></p>
    </section>

    <section>
        <h2>Kỹ năng</h2>
        <ul>
            <li>Thiết kế giao diện bằng Figma, Adobe XD</li>
            <li>Hiểu biết cơ bản về nguyên tắc UX/UI</li>
            <li>Tư duy trực quan và khả năng trình bày ý tưởng</li>
            <li>Kỹ năng teamwork và tiếp thu phản hồi</li>
            <li>Ngôn ngữ lập trình: HTML, CSS, JavaScript, C#, ASP.NET</li>
            <li>Cơ sở dữ liệu: SQL Server</li>
        </ul>
    </section>

    <section>
        <h2>Học vấn</h2>
        <p><strong>Cử Nhân</strong> Đại học Khoa học – Đại học Huế</p>
        <p>Chuyên ngành: Kỹ thuật Phần mềm</p>
        <p>Phụ: Công nghệ Thông tin</p>
    </section>

    <section>
        <h2>Kinh nghiệm làm việc / Thực tập</h2>
        <ul>
            <li><strong>01/2021 – 05/2023:</strong> Công ty Bánh Ba Thảo (Part-time, Trợ lý Marketing Hiệu suất)<br>
                - Nghiên cứu, xác định khách hàng tiềm năng.<br>
                - Phân tích, xây dựng chiến lược quảng cáo trên Facebook, Zalo.<br>
                - Tối ưu dữ liệu, mở rộng tệp khách hàng.
            </li>
            <li><strong>07/2024 – 09/2024:</strong> Trung tâm CNTT tỉnh Thừa Thiên Huế (HueCIT) – Thực tập sinh<br>
                - Được hướng dẫn về DNN và MVC ASP.NET.<br>
                - Thiết kế & triển khai module DNN.<br>
                - Phát triển ứng dụng web bằng ASP.NET Core.
            </li>
        </ul>
    </section>

    <section>
        <h2>Dự án</h2>
        <ul>
            <li><strong>Blog cá nhân:</strong> Xây dựng website cá nhân bằng ASP.NET Core MVC.</li>
            <li><strong>Website bán đồng hồ:</strong> Thiết kế giao diện & xây dựng website thương mại điện tử.</li>
            <li><strong>IoT Smart Home:</strong> Ứng dụng IoT điều khiển thiết bị gia đình (đèn, quạt) qua Internet.</li>
            <li><strong>App quản lý thư viện:</strong> Phần mềm quản lý sách & người mượn bằng C# WinForms.</li>
        </ul>
    </section>
</div>
</body>
</html>
